<?php

$function_list['server_get,server_config_set,get_function_list,client_templates_get_all,server_get_serverid_by_ip,server_ip_get,server_ip_add,server_ip_update,server_ip_delete,system_config_set,system_config_get,config_value_get,config_value_add,config_value_update,config_value_replace,config_value_delete'] = 'Server functions';
$function_list['admin_record_permissions'] = 'Record permission changes';

?>
