<?php

/*
	The admin.conf.php file contains menu definitions to be displayed in the administration module.
*/


?>
