<?php

$function_list['vm_openvz'] = 'OpenVZ VM functions';

?>
