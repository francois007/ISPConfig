<?php
/* Removed because tpl_default.php does not work
for($m = 0; $m < count($module['nav']); $m++) {
    if($module['nav'][$m]['title'] == 'Interface') {

        $module['nav'][$m]['items'][] = array(  'title'     => 'Default Theme',
                                                'target' 	=> 'content',
                                                'link'	=> 'admin/tpl_default.php',
                                                'html_id'   => 'tpl_default');
        break;
    }
}
*/

?>
